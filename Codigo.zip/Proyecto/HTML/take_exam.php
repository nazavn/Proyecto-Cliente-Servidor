<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.html");
    exit();
}

include 'db.php';
$student_id = $_SESSION['student_id'];
$exam_id = $_GET['exam_id'];

// Obtener las preguntas del examen
$sql = "SELECT questions.id, questions.question_text, questions.correct_answer, questions.wrong_answer1, questions.wrong_answer2, questions.wrong_answer3 
        FROM questions 
        JOIN exams ON questions.subject_id = exams.subject_id 
        WHERE exams.id = '$exam_id'";
$questions_result = $conn->query($sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Procesar las respuestas del examen
    $correct = 0;
    $total = 0;

    foreach ($_POST['answers'] as $question_id => $selected_answer) {
        $sql = "SELECT correct_answer FROM questions WHERE id='$question_id'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        if ($row['correct_answer'] == $selected_answer) {
            $correct++;
        }
        $total++;
    }

    $score = ($correct / $total) * 100;

    // Guardar la nota en la tabla grades
    $subject_id_query = "SELECT subject_id FROM exams WHERE id='$exam_id'";
    $subject_id_result = $conn->query($subject_id_query);
    $subject_id_row = $subject_id_result->fetch_assoc();
    $subject_id = $subject_id_row['subject_id'];

    $insert_grade_sql = "INSERT INTO grades (student_id, subject_id, grade) VALUES ('$student_id', '$subject_id', '$score')";
    $conn->query($insert_grade_sql);

    // Redirigir a grades.php
    header("Location: grades.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tomar Examenes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body class="bg-light text-dark">
    <header class="bg-dark-blue text-white">
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">Perfil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="grades.php">Notas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="exams.php">Exámenes Disponibles</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container">
        <section class="exam-questions">
            <h2>Examen</h2>
            <form action="take_exam.php?exam_id=<?php echo $exam_id; ?>" method="POST">
                <?php
                if ($questions_result->num_rows > 0) {
                    while($row = $questions_result->fetch_assoc()) {
                        echo "<div class='question'>";
                        echo "<p>" . $row['question_text'] . "</p>";
                        echo "<label><input type='radio' name='answers[" . $row['id'] . "]' value='" . $row['correct_answer'] . "'> " . $row['correct_answer'] . "</label><br>";
                        echo "<label><input type='radio' name='answers[" . $row['id'] . "]' value='" . $row['wrong_answer1'] . "'> " . $row['wrong_answer1'] . "</label><br>";
                        echo "<label><input type='radio' name='answers[" . $row['id'] . "]' value='" . $row['wrong_answer2'] . "'> " . $row['wrong_answer2'] . "</label><br>";
                        echo "<label><input type='radio' name='answers[" . $row['id'] . "]' value='" . $row['wrong_answer3'] . "'> " . $row['wrong_answer3'] . "</label><br>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No se encontraron preguntas para este examen.</p>";
                }
                ?>
                <button type="submit" class="button">Enviar Respuestas</button>
            </form>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 BachiEduca. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
