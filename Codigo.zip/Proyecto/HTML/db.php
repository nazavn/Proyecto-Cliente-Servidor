<?php
$servername = "localhost";
$username = "root";!
$password = "HDECACHEBROS!1999!";
$dbname = "exam_preparation";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
