<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.html");
    exit();
}

include 'db.php';
$student_id = $_SESSION['student_id'];

$sql = "SELECT exams.id, subjects.name AS subject, exams.date 
        FROM exams 
        JOIN subjects ON exams.subject_id = subjects.id 
        WHERE exams.date >= CURDATE()";
$exams_result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examenes disponibles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body class="bg-light text-dark">
    <header class="bg-dark-blue text-white">
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">Perfil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="grades.php">Notas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="exams.php">Exámenes Disponibles</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container">
        <section class="exams-info">
            <h2>Exámenes Disponibles</h2>
            <?php
            if ($exams_result->num_rows > 0) {
                echo "<table><tr><th>Materia</th><th>Fecha</th><th>Acción</th></tr>";
                while($row = $exams_result->fetch_assoc()) {
                    echo "<tr><td>" . $row["subject"] . "</td><td>" . $row["date"] . "</td>";
                    echo "<td><a href='take_exam.php?exam_id=" . $row["id"] . "' class='button'>Tomar Examen</a></td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No hay exámenes disponibles.</p>";
            }
            ?>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 BachiEduca. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
