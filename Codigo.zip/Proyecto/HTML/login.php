<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Usar consultas preparadas para evitar inyecciones SQL
    $stmt = $conn->prepare("SELECT * FROM students WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Guardar información del usuario en la sesión
            $_SESSION['student_id'] = $row['id'];
            $_SESSION['student_name'] = $row['name'];
            $_SESSION['role'] = $row['role'];

            // Redirigir según el rol del usuario
            if ($row['role'] === 'admin') {
                header("Location: admin.php"); // Redirigir a la página de administración
                exit();
            } else {
                header("Location: dashboard.php"); // Redirigir a la página de usuario
                exit();
            }
        } else {
            // Manejo de error de contraseña incorrecta
            echo "Contraseña incorrecta.";
        }
    } else {
        // Manejo de error de correo electrónico no encontrado
        echo "No se encontró un usuario con ese correo electrónico.";
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conn->close();
}
?>
