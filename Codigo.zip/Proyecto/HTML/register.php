<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si los campos están definidos
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? password_hash($_POST['password'], PASSWORD_BCRYPT) : '';
    $date_of_birth = isset($_POST['date_of_birth']) ? $_POST['date_of_birth'] : NULL;
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $phone_number = isset($_POST['phone_number']) ? $_POST['phone_number'] : '';

    // Validar que los campos requeridos no estén vacíos
    if (empty($name) || empty($email) || empty($password) || empty($date_of_birth)) {
        $_SESSION['message'] = "Todos los campos son obligatorios.";
        header("Location: login.html");
        exit();
    }

    $sql = "INSERT INTO students (name, email, password, date_of_birth, address, phone_number) 
            VALUES ('$name', '$email', '$password', '$date_of_birth', '$address', '$phone_number')";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = "Nuevo registro creado exitosamente.";
    } else {
        $_SESSION['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }

    header("Location: login.html");
    exit();
}
?>
