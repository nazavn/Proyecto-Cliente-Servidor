<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.html");
    exit();
}

include 'db.php';
$student_id = $_SESSION['student_id'];

// Obtener información del usuario
$sql = "SELECT * FROM students WHERE id='$student_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Obtener notas del usuario
$sql = "SELECT subjects.name AS subject, grades.grade 
        FROM grades 
        JOIN subjects ON grades.subject_id = subjects.id 
        WHERE grades.student_id = '$student_id'";
$grades_result = $conn->query($sql);

// Obtener exámenes disponibles
$sql = "SELECT subjects.name AS subject, exams.date 
        FROM exams 
        JOIN subjects ON exams.subject_id = subjects.id 
        WHERE exams.date >= CURDATE()";
$exams_result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body class="bg-light text-dark">
    <header class="bg-dark-blue text-white">
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="../img/bachieduca-high-resolution-logo-Photoroom.png" alt="Logo" class="logo" />
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <?php if (isset($_SESSION['student_id'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="profile.php">Perfil</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="grades.php">Notas</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="exams.php">Exámenes Disponibles</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="index.html">Inicio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="registro.html">Registro</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Material_Didactico.html">Material Didáctico</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Materias.html">Materias</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="videos.html">Videos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Noticias.html">Noticias</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <?php if (isset($_SESSION['student_id'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.html">Log In</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container">
        <section class="user-info">
            <h2>Información del Usuario</h2>
            <p><strong>Nombre:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
            <p><strong>Correo Electrónico:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Fecha de Nacimiento:</strong> <?php echo htmlspecialchars($user['date_of_birth']); ?></p>
            <p><strong>Dirección:</strong> <?php echo htmlspecialchars($user['address']); ?></p>
            <p><strong>Número de Teléfono:</strong> <?php echo htmlspecialchars($user['phone_number']); ?></p>
        </section>

        <section class="grades-info">
            <h2>Notas de las Materias</h2>
            <?php
            if ($grades_result->num_rows > 0) {
                echo "<table class='table'><tr><th>Materia</th><th>Nota</th></tr>";
                while($row = $grades_result->fetch_assoc()) {
                    echo "<tr><td>" . htmlspecialchars($row["subject"]) . "</td><td>" . htmlspecialchars($row["grade"]) . "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No se encontraron notas.</p>";
            }
            ?>
        </section>

        <section class="exams-info">
            <h2>Exámenes Disponibles</h2>
            <?php
            if ($exams_result->num_rows > 0) {
                echo "<table class='table'><tr><th>Materia</th><th>Fecha</th></tr>";
                while($row = $exams_result->fetch_assoc()) {
                    echo "<tr><td>" . htmlspecialchars($row["subject"]) . "</td><td>" . htmlspecialchars($row["date"]) . "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No hay exámenes disponibles.</p>";
            }
            ?>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 BachiEduca. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
