<?php
session_start();
include 'db.php'; // Conexión a la base de datos

if (!isset($_SESSION['loggedin'])) {
    header("Location: login.html");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin.php");
}
?>