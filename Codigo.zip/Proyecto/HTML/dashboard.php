<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.html");
    exit();
}

include 'db.php';
$student_id = $_SESSION['student_id'];

// Obtener información del usuario
$sql = "SELECT * FROM students WHERE id='$student_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body class="bg-light text-dark">
    <header class="bg-dark-blue text-white">
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">Perfil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="grades.php">Notas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="exams.php">Exámenes Disponibles</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container">
        <section class="user-info">
            <h2>Bienvenido, <?php echo $user['name']; ?></h2>
            <p>Selecciona una de las opciones del menú para ver tu perfil, tus notas, o los exámenes disponibles.</p>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 BachiEduca. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
