<?php
include 'db.php'; // Conexión a la base de datos

// Manejo de la subida de archivos
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['upload'])) {
    $subject = $_POST['subject']; // Obtener la materia desde el formulario
    $file_name = $_POST['file_name'];
    $pdf_file = $_FILES['pdf_file'];

    // Verificar si el archivo es un PDF
    if ($pdf_file['type'] == 'application/pdf') {
        // Mover el archivo a la carpeta deseada
        $target_dir = "uploads/"; // Asegúrate de que esta carpeta exista y tenga permisos de escritura
        $target_file = $target_dir . basename($pdf_file["name"]);

        if (move_uploaded_file($pdf_file["tmp_name"], $target_file)) {
            // Guardar información en la base de datos
            $stmt = $conn->prepare("INSERT INTO files (file_name, subject) VALUES (?, ?)");
            $stmt->bind_param("si", $pdf_file["name"], $subject); // Cambiado a "si"
            if ($stmt->execute()) {
                echo "El archivo ha sido subido exitosamente.";
            } else {
                echo "Error al insertar en la base de datos: " . $stmt->error;
            }
        } else {
            echo "Lo siento, hubo un error al subir tu archivo.";
        }
    } else {
        echo "Solo se permiten archivos PDF.";
    }
}

// Manejo de la eliminación de archivos
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("SELECT file_name FROM files WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $file_path = "uploads/" . $row['file_name'];
        if (unlink($file_path)) { // Eliminar el archivo del servidor
            $stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
            $stmt->bind_param("i", $delete_id);
            $stmt->execute();
            echo "El archivo ha sido eliminado exitosamente.";
        } else {
            echo "Error al eliminar el archivo del servidor.";
        }
    } else {
        echo "Archivo no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Material Didáctico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light text-dark">
    <header class="bg-dark text-white">
        <h1>Panel de Administración - Material Didáctico</h1>
    </header>
    <div class="container">
        <h2>Subir Nuevo Archivo</h2>
        <form action="admin.php" method="post" enctype="multipart/form-data">
            <label for="subject">Seleccionar Materia:</label>
            <select name="subject" required>
                <option value="1">Español</option>
                <option value="2">Inglés</option>
                <option value="3">Estudios Sociales</option>
                <option value="4">Matemática</option>
                <option value="5">Biología</option>
                <option value="6">Física</option>
                <option value="7">Química</option>
                <option value="8">Educación Cívica</option>
            </select>
            <label for="file_name">Nombre del archivo:</label>
            <input type="text" name="file_name" required>
            <label for="pdf_file">Seleccionar archivo PDF:</label>
            <input type="file" name="pdf_file" accept="application/pdf" required>
            <button type="submit" name="upload">Subir PDF</button>
        </form>

        <h2>Archivos Disponibles</h2>
        <ul class="material-list">
            <?php
            $result = $conn->query("SELECT id, file_name, subject FROM files");
            while ($row = $result->fetch_assoc()) {
                echo "<li>
                        {$row['file_name']} (Materia ID: {$row['subject']})
                        <a href='admin.php?delete_id={$row['id']}' style='color: red;'>Eliminar</a>
                      </li>";
            }
            ?>
        </ul>
    </div>
    <footer>
        <p>&copy; 2024 Institución Educativa. Todos los derechos reservados.</p>
    </footer>
</body>
</html>